# part I: load files
{
source("plot_pca.R")

  ref.df <- read.csv("reference.csv", row.names = 1)
  meta.df <- read.csv("metadata.csv")
  sample.df <- read.csv("sample.csv", row.names = 1)
}

# part II: plot graph
{
  pca.df <- cbind(ref.df, sample.df) #join ref.df, sample.df
  pca.obj <- prcomp(t(pca.df)) #run pca
  pca.plot.df <- pca.obj$x[,1:2] #get pc1 and pc2

  cell.type <- c(meta.df$cell.type, rep("sample", 3))
  pca.plot.df <- as.data.frame(cbind(pca.plot.df, cell.type))
  pca.plot.df$PC1 <- as.numeric(pca.plot.df$PC1) #change PC1 back to numeric
  pca.plot.df$PC2 <- as.numeric(pca.plot.df$PC2) #change PC2 back to numeric

  # plot graph
  plot_pca(pca.plot.df, "Sample 1 PCA plot") # call plot pca function
}

# part III: run kNN
{
  k <- 5

  result.df <- data.frame()
  # for each cell in sample.df
  for (m in 1:length(sample.df[1,])) {
    cell <- colnames(sample.df)[m]
    test <- sample.df[,m]

    # make placeholder for distance and barcode
    distance <- rep(NA, length(ref.df[1,]))
    barcode <- rep(NA, length(ref.df[1,]))

    # for each barcode in ref.df
    for (n in 1:length(ref.df[1,])) {
      barcode[n] <- colnames(ref.df)[n]
      train <- ref.df[,n]

      # calculate the distance
      distance[n] <- sqrt(sum((train - test)^2))
    }

    # find the k nearest barcode
    distance.df <- data.frame(barcode, distance)
    k_nearest <- head(distance.df[order(distance.df$distance),], k)

    # find the class of the k nearest barcode
    k_nearest$cell.type <- meta.df[which(meta.df$barcode %in% k_nearest$barcode),]$cell.type
    cell.result <- cbind(cell = rep(cell, k), k_nearest)
    result.df <- rbind(result.df, cell.result)
  }
}
result.df

# part IV: find maxx class
{
  #make a count table between cell and cell.type
  result.count <- with(result.df, table(cell, cell.type))

  #find for each row, which column has the max value
  max.class <- colnames(result.count)[apply(result.count,1,which.max)]

  #save result in knn.result.df
  knn.result.df <- data.frame(cell = rownames(result.count), cell.type = max.class)
}
knn.result.df
