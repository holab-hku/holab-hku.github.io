plot_pca <- function(pca.plot.df, title) {
  par(pty = "s")
  with(pca.plot.df,
       plot(PC1, PC2, main = title, type = "n", xlim = c(-6,4), ylim = c(-6,4)))
  with(subset(pca.plot.df, cell.type == "B Cells"), 
       points(PC1, PC2, col = "red", pch = 16, cex = 0.8, xlim = c(-6,4), ylim = c(-6,4)))
  with(subset(pca.plot.df, cell.type == "CD4+ T Cells"), 
       points(PC1, PC2, col = "orange", pch = 16, cex = 0.8, xlim = c(-6,4), ylim = c(-6,4)))
  with(subset(pca.plot.df, cell.type == "CD8+ T Cells"), 
       points(PC1, PC2, col = "limegreen", pch = 16, cex = 0.8, xlim = c(-6,4), ylim = c(-6,4)))
  with(subset(pca.plot.df, cell.type == "Monocytes"), 
       points(PC1, PC2, col = "cyan", pch = 16, cex = 0.8, xlim = c(-6,4), ylim = c(-6,4)))
  with(subset(pca.plot.df, cell.type == "Natural Killer Cells"), 
       points(PC1, PC2, col = "magenta", pch = 16, cex = 0.8, xlim = c(-6,4), ylim = c(-6,4)))
  with(subset(pca.plot.df, cell.type == "sample"), 
       points(PC1, PC2, col = "black", pch = 17, cex = 1.5, xlim = c(-6,4), ylim = c(-6,4)))
  
  legend("bottomleft",
         pch = c(16,16,16,16,16,17),
         col = c("red", "orange", "limegreen", "cyan", "magenta", "black"),
         legend = c("B Cells", "CD4+ T Cells", "CD8+ T Cells", "Monocytes", "Natural Killer Cells", "Unknown Sample"),
         cex = 0.9)
}